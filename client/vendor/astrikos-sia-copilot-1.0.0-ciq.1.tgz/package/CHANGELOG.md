# Changelog

## 1.0.0-ciq.1 — 2026-11-20 (ClinkerIQ vendor build)

- `screen.adhoc` handlers may return a Promise; `spec.chips` are shown with the spoken answer.
- When the rule brain misses and `screen.adhoc.llm` exists, the question becomes `{ type: 'llm', q }`
  so a POC can answer it from its own server (grounded LLM). Candidate for upstream 1.1.0.

## 1.0.0 — 2026-10-09

First release, extracted from the BFSI PDL POC's built-in Copilot.

- Engine, chat window, ambient field, voice input, narration and sounds as one package.
- Rule-based brain with a per-POC knowledge pack (pages, KPIs, glossary, custom rules) instead of BFSI content baked in.
- Router-agnostic: `navigate` and optional `path` props, so POCs without react-router work.
- Narrator pronunciation table: "S!a" is spoken as "See-ah"; POCs can add their own rules.
- Colours follow the Astrikos standard UI `--app-*` tokens when present, with built-in dark and light palettes otherwise.
- Starter template in `templates/copilot/`.
