/*
 * Wire the Copilot into this POC. Wrap the app with <PocCopilot> (inside the router, if there is one)
 * and put <CopilotButton /> in the header.
 */
import React from 'react';
import { useNavigate } from 'react-router-dom'; // remove if this POC has no router — see below
import { SiaCopilot, useCopilotFacts } from '@astrikos/sia-copilot';
import '@astrikos/sia-copilot/style.css';
import { TOUR_CONFIG } from './tours';
import { KNOWLEDGE } from './knowledge';

const IDENTITY = { name: 'S!a', spokenName: 'See-ah', product: 'Your POC name' };

/* Optional: live data the brain can use in glossary definitions and custom rules. */
function Facts() {
  useCopilotFacts({ /* e.g. rules: store.rules, customers: store.customers */ });
  return null;
}

/* With react-router. */
export default function PocCopilot({ enabled = true, children }) {
  const navigate = useNavigate();
  return (
    <SiaCopilot enabled={enabled} tours={TOUR_CONFIG} knowledge={KNOWLEDGE} identity={IDENTITY} navigate={navigate}>
      {children}
      <Facts />
    </SiaCopilot>
  );
}

/*
 * Without a router (the screen is chosen by state, e.g. tabs): pass the current "path" and a
 * navigate that switches it. Paths in tours.js and knowledge.js are then your tab keys.
 *
 *   const [tab, setTab] = useState('/');
 *   <SiaCopilot path={tab} navigate={setTab} tours={TOUR_CONFIG} knowledge={KNOWLEDGE} identity={IDENTITY}>
 *     <App tab={tab} onTab={setTab} />
 *   </SiaCopilot>
 */
