/*
 * Walkthrough scripts for this POC — copy this folder to src/copilot/ and rewrite the content.
 *
 * Each step:
 *   path      route to be on (navigates if different; carried forward when omitted)
 *   target    element to spotlight: a CSS selector, or a finder like kpiCard('Revenue')
 *   title     short name, shown in the chat and the chapter list
 *   say       narration (spoken + captioned) — or (el) => string to read something off the screen
 *   value     the "why it matters" line
 *   click     'before' | 'after' — click the target before or after narrating
 *   pre/do/during/post: async (h, el) => …  scripted actions (h.click, h.type, h.select, h.key,
 *             h.escape, h.wait, h.point, h.go, plus anything passed in <SiaCopilot actions>)
 *   optional  skip quietly if the target is not on screen (use it for anything live data may not produce)
 *   hold      pause after the step, ms · speak: false = captions only · timeout: wait for target, ms
 *
 * Most robust targets: put data-tour-id="…" on the element and use byTourId('…').
 */
import { byTourId, byText, kpiCard, buildFullTour } from '@astrikos/sia-copilot';

export const TOURS = {
  overview: {
    title: 'Overview',
    blurb: 'The live dashboard',
    steps: [
      { path: '/', title: 'Welcome',
        say: 'This is the operations dashboard. Everything on screen is live and updates as events arrive.',
        value: 'The team works from today’s facts, not yesterday’s report.' },
      { target: kpiCard('Revenue today'), click: 'after', title: 'Live KPIs',
        say: 'The cards across the top are the numbers the business runs on. Let’s open one.' },
      { target: byTourId('kpi-detail'), title: 'Drill into a number', post: (h) => h.escape(),
        say: 'Every card opens its trend, a forecast and a breakdown.' },
      { target: byTourId('main-chart'), title: 'I can drive the charts',
        say: 'Every chart has the same controls. I’ll switch it to seven days and back.',
        during: async (h) => { await h.wait(1500); await h.click(byText('button', '7D')); await h.wait(1500); await h.click(byText('button', '24H')); } },
    ],
  },
  reports: {
    title: 'Reports',
    blurb: 'Download any view',
    steps: [
      { path: '/reports', title: 'Reports',
        say: 'Any view can be downloaded as a branded report.' },
    ],
  },
};

export const TOUR_ORDER = ['overview', 'reports'];

export const FULL_TOUR = buildFullTour({
  tours: TOURS,
  order: TOUR_ORDER,
  intro: { path: '/', title: 'Welcome', say: 'Welcome. I’ll drive from here — pause me, step back or jump to a chapter at any time.' },
  outro: { title: 'Summary', say: 'That is the platform: live data, one place, decisions on the same screen as the numbers.' },
});

/** Which chapter belongs to the page the presenter is on. */
export function tourKeyForPath(pathname = '/') {
  const p = `/${pathname.split('/')[1] || ''}`;
  return { '/': 'overview', '/reports': 'reports' }[p] || 'overview';
}

/* What the Copilot appears to be asked before each chapter — it types itself into the chat. */
const PROMPTS = {
  full: 'Take control of my screen and walk me through the whole platform.',
  overview: 'Walk me through the dashboard.',
  reports: 'Show me how reports are downloaded.',
};

export const TOUR_CONFIG = { tours: TOURS, order: TOUR_ORDER, full: FULL_TOUR, keyForPath: tourKeyForPath, prompts: PROMPTS };
