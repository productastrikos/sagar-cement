/*
 * What the Copilot knows about this POC. The brain answers only from this, the tour scripts and
 * what is on screen — so it never makes a number up. Keep keyword lists (kw) in lower case.
 */
export const KNOWLEDGE = {
  // Pages S!a can open: "open reports", "go to the dashboard".
  pages: [
    { path: '/', name: 'the Dashboard', short: 'Dashboard', key: 'overview', kw: ['dashboard', 'home', 'overview', 'main screen'], blurb: 'Live KPIs and trends.' },
    { path: '/reports', name: 'Reports', short: 'Reports', key: 'reports', kw: ['reports', 'report page', 'downloads'], blurb: 'Branded downloads of any view.' },
  ],

  // Figures S!a reads off the screen. `label` must match the start of the KPI card's aria-label.
  kpis: [
    { id: 'revenue', label: 'Revenue today', path: '/', name: 'Revenue today', kw: ['revenue today', 'revenue', 'how much did we make', 'sales today'] },
  ],

  // Terms. `def` can be a function of live facts. `show` points at a tour step that demonstrates it.
  glossary: [
    { id: 'forecast', name: 'The forecast', kw: ['forecast', 'prediction'], def: 'Every chart carries a forecast with a 95 percent range, built from the live data.', show: { key: 'overview', title: 'I can drive the charts' } },
  ],

  pitch: 'This platform puts the live numbers, the forecast and the next action on one screen.',

  // "walk me through …" → which chapter. 'full' is the whole walkthrough.
  chapters: [
    ['full', ['everything', 'whole', 'entire', 'the platform', 'the demo', 'demo', 'tour', 'walkthrough', 'around']],
    ['overview', ['dashboard', 'overview', 'kpi', 'home']],
    ['reports', ['report', 'reports', 'download', 'export']],
  ],

  // Suggested questions per chapter, offered when S!a does not understand.
  suggest: {
    overview: ['What is revenue today?', 'What is the forecast?', 'Walk me through this screen'],
    reports: ['Show me around', 'Open the dashboard'],
  },

  // The chat's opening card and the "what can you do" chips.
  hello: { examples: ['show me around', 'what is revenue today?', 'what is the forecast?'] },
  helpChips: ['Show me around', 'What is revenue today?', 'Open reports'],
  greetChips: ['Show me around', 'What can you do?'],

  // Optional: domain words speech recognition mishears, and acronyms to spell out when speaking.
  aliases: [],
  speech: [],

  // Optional: your own rules — see README → "Knowledge pack" → rules.
  // rules: { afterCommands: [], data: [] },
};
