# @astrikos/sia-copilot

**S!a Copilot** — a guided-walkthrough agent for Astrikos React POCs. It takes the screen, moves
its own cursor, clicks and types into the real app, narrates out loud with captions, listens for
voice commands, and answers questions about what is on screen.

One package, every POC: the engine lives here; each POC only supplies its **tour scripts** and its
**knowledge pack**.

---

## How it works

| Part | File | Job |
|---|---|---|
| Script | *(your POC)* `tours.js` | Each walkthrough is a list of steps written as data: where to go, what to point at, what to say, what to click or type. |
| Engine | `src/SiaCopilot.jsx` | Plays the steps one by one: navigates, waits for the element, glides the cursor, spotlights it, speaks sentence by sentence while running the step's actions. |
| Brain | `src/brain.js` | Turns anything typed or said into a decision — answer, run a command, open a page, read a figure, show a step. **Rule-based, no AI model.** |
| Mouth | `src/speech.js` | Speaks through the browser's built-in speech engine (Web Speech API). Picks the best installed voice; applies the pronunciation table (S!a → "See-ah"). |
| Ears | `src/voice.js` | Always-on voice input (Chrome/Edge). Restarts itself, pauses while S!a talks, and drops its own echo. |
| Stage | `Copilot.jsx`, `AmbientField.jsx`, `sfx.js` | The chat window, the purple screen-share glow, captions, sounds made in code (Web Audio API). |

**Key ideas**

- **Declarative tours.** A step says *what* should happen; the engine works out *how*. New tours never touch the engine.
- **The cursor is drawn, not real.** It is an SVG layer over the app. Clicking is `element.click()`, typing sets the value and fires an `input` event — the same DOM automation testing tools use, running inside the page.
- **Cooperative cancellation.** Every run and step carries an id; pause / next / back bump it, and every waiting loop checks "am I still current?" before continuing.
- **Never stalls.** A step marked `optional` is skipped when its element is not on screen.
- **Grounded numbers.** The brain never knows a figure. For "how much did we collect today?" it decides *read the Collected today card*; the engine reads the card on screen. What S!a says always matches what is shown.
- **Pure brain.** `decide(text, ctx)` has no side effects — same input, same output — so it is unit-tested.
- **Rule order.** pending yes/no → commands → your early rules → small talk → follow-ups → walkthroughs → navigation → your data rules → live figures → glossary → search of the tour narration (TF-IDF) → a polite fallback with suggestions.

Honest limits: voice input needs Chrome or Edge and an internet connection (the browser sends audio to Google / Microsoft); narration quality is the browser's — Edge's "Online (Natural)" voices sound human, Chrome on Windows sounds robotic; tour steps that find elements by text or class can break when the UI changes (use `data-tour-id`).

---

## Install

The package is published privately to **GitHub Packages**. Each machine that installs it (your PC and the deploy server) needs a read token once.

1. Create a GitHub *personal access token (classic)* with the `read:packages` scope.
2. Add an `.npmrc` next to the POC's `package.json` — **never commit it** (it holds a secret):
   ```
   @astrikos:registry=https://npm.pkg.github.com
   //npm.pkg.github.com/:_authToken=YOUR_TOKEN
   ```
3. `npm install @astrikos/sia-copilot`

React 17+ is a *peer dependency*: the package uses the POC's own React, never a second copy.

**Offline / before the registry exists:** `npm pack` in this folder makes `astrikos-sia-copilot-<version>.tgz`; copy it into the POC's `vendor/` and `npm install ./vendor/astrikos-sia-copilot-<version>.tgz`.

---

## Add it to a POC

1. **Copy** `templates/copilot/` from this package into the POC as `src/copilot/`.
2. **Wrap the app** (inside the router, if there is one):
   ```jsx
   import PocCopilot from './copilot/Copilot';
   <PocCopilot enabled={user.role === 'superadmin'}><Layout>…</Layout></PocCopilot>
   ```
3. **Add the launcher** to the header: `import { CopilotButton } from '@astrikos/sia-copilot'` → `<CopilotButton />` (pass `className` to match your buttons).
4. **Mark KPI cards** so S!a can read them: `<div data-kpi aria-label="Revenue today: $41.2k">`. Optional: `data-kpi-trend="up 12% vs last week"`, `data-kpi-note="…"`.
5. **Write the content**: `tours.js` (the walkthroughs) and `knowledge.js` (pages, figures, glossary). Give anything a step points at a `data-tour-id`.

Then: **Ctrl+Shift+A** opens it, or say/type "show me around".

### Without a router

If the POC switches screens with state (tabs), pass the current screen and a switcher. Paths in your tours and knowledge pack are then your tab keys:

```jsx
const [tab, setTab] = useState('/');
<SiaCopilot path={tab} navigate={setTab} tours={TOUR_CONFIG} knowledge={KNOWLEDGE}>…</SiaCopilot>
```

---

## `<SiaCopilot>` props

| Prop | Required | What it is |
|---|---|---|
| `tours` | yes | `{ tours, order, full, keyForPath, prompts }` — see the template's `TOUR_CONFIG` |
| `knowledge` | yes | the knowledge pack (below) |
| `navigate` | yes | `(path) => void` — router navigate, or a tab switcher |
| `enabled` | | show it at all (default `true`) |
| `path` | | current route/tab, for POCs without URL routing |
| `identity` | | `{ name: 'S!a', spokenName: 'See-ah', title, product, maker, wake, wakeStrong }` |
| `pronounce` | | extra `[RegExp, 'spoken form']` rules for the narrator |
| `lang` | | speech language (default `en-AU`) |
| `screen` | | `{ kpi: '[data-kpi]', pageTitle: 'h1', readKpi(el, d), adhoc: { [type]: (d, where) => ({ say, tour, after }) } }` |
| `actions` | | extra helpers available to tour steps as `h.<name>()` |
| `onTakeover` | | called when S!a takes the screen (e.g. stop the app's audio) |
| `bottomInset` | | lift captions/status above a bottom bar, px |
| `theme` | | `'light'` / `'dark'` to force a palette; omit to follow the app |

Hooks: `useCopilot()` (state and controls: `open`, `running`, `play(key)`, `openCopilot()`, `playPage(path)`…), `useCopilotFacts(facts)` (hand live data to the brain).

If the app plays its own speech (a call recording read aloud, say), import `speak` / `stopSpeech` from this package rather than using `speechSynthesis` directly — then the microphone knows it is app audio and ignores it.

---

## Knowledge pack

| Field | What it is |
|---|---|
| `pages` | `{ path, name, short, key, kw[], blurb }` — pages S!a can open |
| `kpis` | `{ id, label, path, name, kw[] }` — figures S!a reads off the screen (`label` matches the card's aria-label; or `re` for a pattern) |
| `glossary` | `{ id, name, kw[], def, kpi?, show? }` — `def` may be `(facts) => string`; `show: { key, title }` links a tour step |
| `pitch` | the elevator pitch for "what is this?" |
| `chapters` | `[[key, kw[]]]` — "walk me through …" matching; `'full'` is the whole tour |
| `suggest` | `{ [chapterKey]: [questions] }` — offered when S!a doesn't understand |
| `hello` | `{ text?, examples[] }` — the opening card |
| `help`, `helpChips`, `greetChips` | "what can you do" text and chips |
| `aliases` | `[[RegExp, replacement]]` — words speech recognition mishears |
| `speech` | `[[RegExp, replacement]]` — how to read acronyms aloud |
| `lines` | override replies: `howAreYou {text, chips}`, `isItReal`, `whoAmI`, `whichPart {text, chips}`, `miss[]`, `missAgain[]` |
| `time`, `date`, `locale`, `timeZone` | how to answer "what time is it" |
| `factsFallback` | `(facts) => facts` used by glossary `def` functions when live data is missing |
| `voiceTip`, `shortcutsNote` | settings-panel text (`**bold**` allowed) |
| `rules` | `{ afterCommands: [fn], data: [fn] }` — your own rules (below) |

**Rules** are functions `(api) => decision | null`, tried in order at their stage. `api` gives `s` (the cleaned-up utterance), `facts`, `page`, `done`, `reply`, `chip`, `askChip`, `pick`, `rng`, `hit`, `hasPhrase`, `TOUR_VERB`. Example:

```js
rules: {
  data: [({ s, facts, reply }) => (s.includes('technicians') && facts.techs
    ? reply(`${facts.techs.length} technicians are on shift.`) : null)],
}
```

A rule may return a custom decision type (`{ type: 'brief', … }`) handled by `screen.adhoc.brief`.

---

## Developing this package

```bash
npm install
npm test          # brain, voice and text unit tests (node:test, no extra tools)
npm run build     # → dist/sia-copilot.js + dist/style.css
```

**Versioning (semver).** Bug fix → `1.0.1`. New feature that changes nothing existing → `1.1.0`. Anything a POC must change for → `2.0.0`. Bump with `npm version patch|minor|major`, note it in `CHANGELOG.md`, then publish. POCs pin a version, so a new release never changes a POC until it chooses to upgrade.

**Publish** (needs a token with `write:packages`): `npm publish` — `prepublishOnly` runs the tests and the build first.
